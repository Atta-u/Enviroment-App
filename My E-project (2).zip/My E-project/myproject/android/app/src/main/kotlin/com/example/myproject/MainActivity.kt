package com.example.myproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
