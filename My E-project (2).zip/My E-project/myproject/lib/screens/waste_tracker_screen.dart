import 'package:flutter/material.dart';

class WasteTrackerScreen extends StatefulWidget {
  const WasteTrackerScreen({super.key});

  @override
  State<WasteTrackerScreen> createState() => _WasteTrackerScreenState();
}

class _WasteTrackerScreenState extends State<WasteTrackerScreen> {
  final TextEditingController _plasticController = TextEditingController();
  final TextEditingController _foodController = TextEditingController();
  final TextEditingController _paperController = TextEditingController();

  double? totalWaste;
  String suggestion = "";

  void calculateWaste() {
    double plastic = double.tryParse(_plasticController.text) ?? 0;
    double food = double.tryParse(_foodController.text) ?? 0;
    double paper = double.tryParse(_paperController.text) ?? 0;

    double total = plastic + food + paper;

    setState(() {
      totalWaste = total;

      if (total < 2) {
        suggestion = "🌍 Excellent! You’re living very sustainably!";
      } else if (total < 5) {
        suggestion = "♻️ Good effort! Try reducing plastic and food waste.";
      } else {
        suggestion = "⚠️ Too much waste! Start composting and recycling.";
      }
    });
  }

  void resetFields() {
    _plasticController.clear();
    _foodController.clear();
    _paperController.clear();
    setState(() {
      totalWaste = null;
      suggestion = "";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3F7F2),
      appBar: AppBar(
        backgroundColor: Colors.green.shade700,
        title: const Text("Waste Tracker ♻️"),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Text(
              "Track your daily waste (in kg)",
              style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF1B5E20)),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _plasticController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: "Plastic waste (kg)",
                prefixIcon: Icon(Icons.recycling),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _foodController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: "Food waste (kg)",
                prefixIcon: Icon(Icons.restaurant),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _paperController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: "Paper waste (kg)",
                prefixIcon: Icon(Icons.description),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: calculateWaste,
              icon: const Icon(Icons.calculate),
              label: const Text("Calculate"),
            ),
            const SizedBox(height: 16),
            if (totalWaste != null) ...[
              Text(
                "Total waste: ${totalWaste!.toStringAsFixed(2)} kg/day",
                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 8),
              Text(
                suggestion,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 15),
              ),
            ],
            const SizedBox(height: 20),
            TextButton(
              onPressed: resetFields,
              child: const Text("Reset"),
            ),
          ],
        ),
      ),
    );
  }
}
